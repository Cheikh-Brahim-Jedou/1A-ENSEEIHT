#include <stdio.h>
#include <stdlib.h>
#include "readcmd.h"
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>


void handler_sigchild(int sig) {
   int status;
    pid_t pid;
   if (sig == SIGCHLD) {    
     while ((pid = waitpid(-1, &status, WNOHANG | WUNTRACED | WCONTINUED)) > 0) {
        if (WIFEXITED(status)) {
           printf(" Processus %d terminé (code : %d)\n", pid, WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
          printf(" Processus %d tué par un signal\n", pid);
        } else if (WIFSTOPPED(status)) {
           printf(" Processus %d suspendu\n", pid);
        } else if (WIFCONTINUED(status)) {
         printf("Processus %d repris\n", pid);
        }
    }
  }
  else if (sig == SIGINT) {
     printf("  SIGINT catched ... nothing to do\n");
  }
  else if ( sig == SIGTSTP) {
   printf( " SIGTSTP catched ... nothing to do\n");
   }
}



int main(void) {
    bool fini= false;
    //Etape 11.3    
    sigset_t mask;
    sigemptyset(&mask);
    sigaddset(&mask, SIGINT);
    sigaddset(&mask, SIGTSTP);
    sigprocmask(SIG_BLOCK, &mask, NULL);
    
    struct sigaction sa;
    sa.sa_handler = handler_sigchild;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;
    sigaction(SIGCHLD, &sa, NULL) ;
    //Etape 11.1 
   // sigaction(SIGINT , &sa , NULL);
    //sigaction(SIGTSTP , &sa , NULL);
    
    // Etape 11.2
    //signal(SIGINT , SIG_IGN);
   // signal(SIGTSTP , SIG_IGN);
    while (!fini) {
        printf("> ");
        struct cmdline *commande= readcmd();

        if (commande == NULL) {
            // commande == NULL -> erreur readcmd()
            perror("erreur lecture commande \n");
            exit(EXIT_FAILURE);
    
        } else {

            if (commande->err) {
                // commande->err != NULL -> commande->seq == NULL
                printf("erreur saisie de la commande : %s\n", commande->err);
        
            } else {

                /* Pour le moment le programme ne fait qu'afficher les commandes 
                   tapees et les affiche à l'écran. 
                   Cette partie est à modifier pour considérer l'exécution de ces
                   commandes 
                */
                int indexseq= 0;
                char **cmd;
                while ((cmd= commande->seq[indexseq])) {
                    if (cmd[0]) {
                        if (strcmp(cmd[0], "exit") == 0) {
                            fini= true;
                            printf("Au revoir ...\n");
                        }
                        else {
                            pid_t pid = fork(); // Création du processus fils
                            int status ;
                           if (pid == -1) {
                              perror("Erreur fork");
                              exit(1);
                               
                          } else if (pid == 0) {
                            // Code exécuté par le fils  
                               execvp(cmd[0], cmd);
                               perror("Erreur exec");
                               
                            } else {
                            
                             if (commande->backgrounded == NULL) {
                                 pause();
                                }
                        }

                        
                    }
                }
                indexseq++;
            }
        }
    }
  }
    return EXIT_SUCCESS;

}

